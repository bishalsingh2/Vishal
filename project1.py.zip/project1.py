import pandas as pd 
import matplotlib.pyplot as plt 
import numpy as np
import seaborn as sns 


data=pd.read_csv("/Users/vishal/Documents/StudentsPerformance.csv")
# print(data.head())
print(data.describe())

sns.histplot(data['math score'],bins=20,kde=True,color='skyblue')
plt.title("distribution of math score ")
plt.xlabel('score')
plt.ylabel('frequency')


plt.show()